import os, random, base64, uuid, datetime, zipfile, tempfile, shutil
from flask import Flask, render_template, request, jsonify, send_file
from openpyxl import Workbook, load_workbook

app = Flask(__name__)

XLSX_PATH = 'people.xlsx'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}

# ----------------- Helpers -----------------
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def ensure_workbook():
    """Create Excel with required sheets/headers, or add missing sheets if upgrading."""
    if not os.path.exists(XLSX_PATH):
        wb = Workbook()
        ws_games = wb.active
        ws_games.title = 'games'
        ws_games.append(['id', 'name', 'required_count'])
        ws_players = wb.create_sheet('players')
        ws_players.append(['id', 'name', 'mime', 'b64'])  # Global player pool
        ws_locks = wb.create_sheet('locks')
        ws_locks.append(['player_id', 'locked_at'])       # Prevents repeats across games
        wb.save(XLSX_PATH)
    else:
        wb = load_workbook(XLSX_PATH)
        if 'games' not in wb.sheetnames:
            ws_games = wb.create_sheet('games', 0)
            ws_games.append(['id', 'name', 'required_count'])
        if 'players' not in wb.sheetnames:
            ws_players = wb.create_sheet('players')
            ws_players.append(['id', 'name', 'mime', 'b64'])
        if 'locks' not in wb.sheetnames:
            ws_locks = wb.create_sheet('locks')
            ws_locks.append(['player_id', 'locked_at'])
        wb.save(XLSX_PATH)

def load_games():
    ensure_workbook()
    wb = load_workbook(XLSX_PATH, read_only=True)
    ws = wb['games']
    games = []
    first = True
    for row in ws.iter_rows(values_only=True):
        if first:
            first = False
            continue
        if not row:
            continue
        cells = list(row)
        if len(cells) < 3:
            continue
        gid, name, req = cells[:3]
        if gid and name:
            try:
                req = int(req) if req is not None else 0
            except:
                req = 0
            games.append({'id': str(gid), 'name': str(name), 'required_count': req})
    wb.close()
    return games

def add_game(name, required_count):
    ensure_workbook()
    gid = str(uuid.uuid4())
    wb = load_workbook(XLSX_PATH)
    ws = wb['games']
    ws.append([gid, name, int(required_count)])
    wb.save(XLSX_PATH)
    return gid

def update_game(gid, name, required_count):
    ensure_workbook()
    wb = load_workbook(XLSX_PATH)
    ws = wb['games']
    for r in range(2, ws.max_row + 1):
        if str(ws.cell(row=r, column=1).value) == str(gid):
            ws.cell(row=r, column=2).value = name
            ws.cell(row=r, column=3).value = int(required_count)
            break
    wb.save(XLSX_PATH)

def delete_game(gid):
    ensure_workbook()
    wb = load_workbook(XLSX_PATH)
    ws_g = wb['games']
    row_to_del = None
    for r in range(2, ws_g.max_row + 1):
        if str(ws_g.cell(row=r, column=1).value) == str(gid):
            row_to_del = r
            break
    if row_to_del:
        ws_g.delete_rows(row_to_del, 1)
    wb.save(XLSX_PATH)

def load_global_players(include_b64=True):
    ensure_workbook()
    wb = load_workbook(XLSX_PATH, read_only=True)
    ws = wb['players']
    players = []
    first = True
    for row in ws.iter_rows(values_only=True):
        if first:
            first = False
            continue
        if not row:
            continue
        cells = list(row)
        if len(cells) < 4:
            continue
        pid, name, mime, b64 = cells[:4]
        if pid and name and b64:
            d = {'id': str(pid), 'name': str(name), 'mime': str(mime)}
            if include_b64:
                d['b64'] = b64
            players.append(d)
    wb.close()
    return players

def add_global_player(name, file_storage):
    ensure_workbook()
    data = file_storage.read()
    ext = file_storage.filename.rsplit('.', 1)[-1].lower()
    mime = {
        'png': 'image/png', 'jpg': 'image/jpeg', 'jpeg': 'image/jpeg',
        'gif': 'image/gif', 'webp': 'image/webp'
    }.get(ext, 'application/octet-stream')
    b64 = base64.b64encode(data).decode('utf-8')
    pid = str(uuid.uuid4())
    wb = load_workbook(XLSX_PATH)
    ws = wb['players']
    ws.append([pid, name, mime, b64])
    wb.save(XLSX_PATH)
    return pid

def delete_global_player(pid):
    ensure_workbook()
    wb = load_workbook(XLSX_PATH)
    ws = wb['players']
    target = None
    for r in range(2, ws.max_row + 1):
        if str(ws.cell(row=r, column=1).value) == str(pid):
            target = r
            break
    if target:
        ws.delete_rows(target, 1)
    # also remove lock if present
    ws_l = wb['locks']
    to_del = []
    for r in range(2, ws_l.max_row + 1):
        if str(ws_l.cell(row=r, column=1).value) == str(pid):
            to_del.append(r)
    for i, r in enumerate(to_del):
        ws_l.delete_rows(r - i, 1)
    wb.save(XLSX_PATH)

def load_locked_ids():
    ensure_workbook()
    wb = load_workbook(XLSX_PATH, read_only=True)
    ws = wb['locks']
    locked = set()
    first = True
    for row in ws.iter_rows(values_only=True):
        if first:
            first = False
            continue
        if not row:
            continue
        pid = row[0]
        if pid:
            locked.add(str(pid))
    wb.close()
    return locked

def lock_players(pids):
    ensure_workbook()
    wb = load_workbook(XLSX_PATH)
    ws = wb['locks']
    ts = datetime.datetime.utcnow().isoformat()
    for pid in pids:
        ws.append([pid, ts])
    wb.save(XLSX_PATH)

def reset_locks():
    ensure_workbook()
    wb = load_workbook(XLSX_PATH)
    ws = wb['locks']
    if ws.max_row > 1:
        ws.delete_rows(2, ws.max_row - 1)
    wb.save(XLSX_PATH)

# ----------------- Routes -----------------

@app.route('/')
def home():
    games = load_games()
    total_players = len(load_global_players(include_b64=False))
    return render_template('home.html', games=games, total_players=total_players)

@app.route('/reset', methods=['POST'])
def reset():
    reset_locks()
    return jsonify({'ok': True})

# Games
@app.route('/games', methods=['POST'])
def create_game():
    name = request.form.get('name', '').strip()
    required = request.form.get('required_count', '0').strip()
    if not name:
        return jsonify({'ok': False, 'error': 'Game name is required'}), 400
    try:
        required = int(required)
        if required <= 0:
            raise ValueError()
    except:
        return jsonify({'ok': False, 'error': 'Required players must be a positive integer'}), 400
    gid = add_game(name, required)
    return jsonify({'ok': True, 'id': gid})

@app.route('/games/<gid>', methods=['POST'])
def edit_game(gid):
    name = request.form.get('name', '').strip()
    required = request.form.get('required_count', '0').strip()
    try:
        required = int(required)
    except:
        return jsonify({'ok': False, 'error': 'Invalid required number'}), 400
    update_game(gid, name, required)
    return jsonify({'ok': True})

@app.route('/games/<gid>/delete', methods=['POST'])
def remove_game(gid):
    delete_game(gid)
    return jsonify({'ok': True})

@app.route('/games/<gid>')
def game_detail(gid):
    games = {g['id']: g for g in load_games()}
    game = games.get(str(gid))
    if not game:
        return "Game not found", 404
    players = load_global_players(include_b64=True)
    locked = load_locked_ids()
    for p in players:
        p['locked'] = (p['id'] in locked)
    return render_template('game.html', game=game, players=players)

@app.route('/games/<gid>/randomize')
def randomize(gid):
    games = {g['id']: g for g in load_games()}
    game = games.get(str(gid))
    if not game:
        return jsonify({'error': 'Game not found'}), 404
    players = load_global_players(include_b64=True)
    locked = load_locked_ids()
    available = [p for p in players if p['id'] not in locked]
    n = game['required_count']
    if len(available) < n:
        return jsonify({'error': f'Need {n} players but only {len(available)} available (others are locked by previous games). Use Reset to clear locks.'}), 400
    picks = random.sample(available, n)
    lock_players([p['id'] for p in picks])
    out = [{'id': p['id'], 'name': p['name'], 'photo': f"data:{p['mime']};base64,{p['b64']}"} for p in picks]
    return jsonify({'game': game, 'picks': out})

# Global Players API (used by home form)
@app.route('/players', methods=['POST'])
def add_player_api():
    name = request.form.get('name', '').strip()
    file = request.files.get('photo')
    if not name:
        return jsonify({'ok': False, 'error': 'Player name is required'}), 400
    if not file or file.filename == '':
        return jsonify({'ok': False, 'error': 'Choose a photo'}), 400
    if not allowed_file(file.filename):
        return jsonify({'ok': False, 'error': 'Unsupported file type'}), 400
    pid = add_global_player(name, file)
    return jsonify({'ok': True, 'id': pid})

@app.route('/players/<pid>', methods=['DELETE', 'POST'])
def delete_player_api(pid):
    delete_global_player(pid)
    return jsonify({'ok': True})

# Export / Import
@app.route('/export')
def export_zip():
    ensure_workbook()
    tmp_dir = tempfile.mkdtemp()
    zip_fp = os.path.join(tmp_dir, 'Quantum_Pick_data.zip')
    with zipfile.ZipFile(zip_fp, 'w', zipfile.ZIP_DEFLATED) as zf:
        if os.path.exists(XLSX_PATH):
            zf.write(XLSX_PATH, arcname='people.xlsx')
    return send_file(zip_fp, as_attachment=True, download_name='Quantum_Pick_data.zip')

@app.route('/import', methods=['POST'])
def import_xlsx():
    file = request.files.get('file')
    if not file or not file.filename.lower().endswith('.xlsx'):
        return jsonify({'ok': False, 'error': 'Please upload a .xlsx file'}), 400
    if os.path.exists(XLSX_PATH):
        backup = XLSX_PATH.replace('.xlsx', '.bak.xlsx')
        try:
            shutil.copyfile(XLSX_PATH, backup)
        except Exception:
            pass
    file.save(XLSX_PATH)
    return jsonify({'ok': True, 'message': 'Data imported'})

# Back-compat for older template posts
@app.route('/games/<gid>/players', methods=['POST'])
def add_game_player_compat(gid):
    return add_player_api()

@app.route('/import-music', methods=['POST'])
def import_music():
    file = request.files.get('file')
    if not file or file.filename == '':
        return jsonify({'ok': False, 'error': 'No file selected'}), 400
    fn = file.filename.lower()
    if not (fn.endswith('.mp3') or fn.endswith('.ogg') or fn.endswith('.wav')):
        return jsonify({'ok': False, 'error': 'Only .mp3, .ogg, .wav allowed'}), 400
    save_dir = os.path.join('static', 'audio')
    os.makedirs(save_dir, exist_ok=True)
    save_path = os.path.join(save_dir, 'theme.mp3')
    file.save(save_path)
    return jsonify({'ok': True})

if __name__ == '__main__':
    ensure_workbook()
    app.run(debug=True, host='0.0.0.0', port=5000)
