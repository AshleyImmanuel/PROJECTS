# Quantum Pick — Website (File Uploads)

This is a simple website with a Flask backend and a HTML/CSS/JS frontend.
It supports **uploading a photo file** with a person's name (no URL pasting), stores files under `static/uploads`, and lets you pick a random entry.

## How it works
- **Frontend**: `templates/index.html` — standard HTML form and JS `fetch` calls.
- **Backend**: `app.py` (Flask) — exposes `/upload` and `/random_pick` routes.
- **Storage**: `people.csv` keeps `name,filename` pairs; images are saved under `static/uploads/`.

## Run locally
```bash
python app.py
# Visit http://localhost:5000
```

## Deploy as a website
You need a host that runs a small Python web server (because file uploads require server-side handling). Options:
- **Render** (free web service): connects to a repo and runs the app with `gunicorn app:app`.
- **Railway** or **Fly.io**: similar setup.
- **Heroku**: if available, uses this repo with `Procfile` and `requirements.txt`.
- **Your own VPS / VM**: use `gunicorn` + `nginx` (reverse proxy) for production.

### Quick Heroku-like setup
1. Create a new Git repo with these files.
2. Ensure `requirements.txt` and `Procfile` are present.
3. Push to your host. Command used by the host should be:
   ```
   gunicorn app:app
   ```

> Note: Pure static hosts (e.g., GitHub Pages, Netlify static) won't work for uploads because they don't run Python.
