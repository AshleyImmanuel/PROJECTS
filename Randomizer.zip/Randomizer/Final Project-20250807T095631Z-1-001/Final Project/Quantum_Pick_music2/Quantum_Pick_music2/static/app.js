(function(){
  // Theme persistence
  const root = document.documentElement;
  const key = 'qp-theme';

  function setTheme(mode){
    root.classList.toggle('light', mode === 'light');
    localStorage.setItem(key, mode);
  }

  // Apply saved theme immediately (before paint)
  const saved = localStorage.getItem(key) || 'dark';
  setTheme(saved);

  // Wire up the toggle when DOM is ready
  window.addEventListener('DOMContentLoaded', () => {
    const toggle = document.querySelector('#themeSwitch');
    if (toggle) {
      toggle.checked = (localStorage.getItem(key) === 'light');
      toggle.addEventListener('change', () => setTheme(toggle.checked ? 'light' : 'dark'));
    }
  });

  // Simple toast
  window.toast = function(msg, ok=true){
    const t = document.createElement('div');
    t.textContent = msg;
    t.style.position='fixed'; t.style.right='20px'; t.style.bottom='20px';
    t.style.padding='10px 12px'; t.style.borderRadius='12px';
    t.style.background = ok ? 'var(--accent)' : '#ef4444';
    t.style.color = ok ? 'var(--accent-contrast)' : '#fff';
    t.style.boxShadow='var(--shadow)'; t.style.zIndex=9999;
    t.style.opacity='0'; t.style.transform='translateY(6px)';
    t.style.transition='opacity .25s ease, transform .25s ease';
    document.body.appendChild(t);
    requestAnimationFrame(()=>{ t.style.opacity='1'; t.style.transform='translateY(0)'; });
    setTimeout(()=>{
      t.style.opacity='0'; t.style.transform='translateY(6px)';
      setTimeout(()=> t.remove(), 250);
    }, 2200);
  };
})();
