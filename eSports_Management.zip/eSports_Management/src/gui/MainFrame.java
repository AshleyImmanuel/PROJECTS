package gui;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JTabbedPane;
import javax.swing.JComponent;
import java.awt.Font; // Already added
import javax.swing.JPanel; // Added this import
import javax.swing.JLabel; // Added this import

import eSports_Management.DBInit;

public class MainFrame extends JFrame {
    private static final long serialVersionUID = 1L;

    public static void main(String[] args) {
        DBInit.createTables(); // Ensure tables exist
        EventQueue.invokeLater(() -> {
            try {
                MainFrame frame = new MainFrame();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public MainFrame() {
        setTitle("eSports Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 900, 600);
        setLocationRelativeTo(null);

        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.setFont(new Font("Arial", Font.BOLD, 16));
        
        // Add panels safely
        addTabSafely(tabbedPane, "View Teams",   new ViewTeamsPanel());
        addTabSafely(tabbedPane, "Add New Team", new AddTeamPanel(tabbedPane));
        addTabSafely(tabbedPane, "View Players", new ViewPlayersPanel());
        addTabSafely(tabbedPane, "Add New Player", new AddPlayerPanel(tabbedPane));
        addTabSafely(tabbedPane, "Team Roster", new PlayerRosterPanel());
        addTabSafely(tabbedPane, "Reports", new ReportsPanel());
        addTabSafely(tabbedPane, "Update Player", new UpdatePlayerPanel());
        addTabSafely(tabbedPane, "Update Team", new UpdateTeamPanel());
        addTabSafely(tabbedPane, "Delete Player", new DeletePlayerPanel());
        addTabSafely(tabbedPane, "Delete Team", new DeleteTeamPanel());

        getContentPane().add(tabbedPane);
    }

    private void addTabSafely(JTabbedPane tabbedPane, String title, JComponent panel) {
        try {
            tabbedPane.addTab(title, panel);
        } catch (Exception e) {
            System.err.println("Failed to add tab '" + title + ": " + e.getMessage());
            e.printStackTrace();
            JPanel errorPanel = new JPanel(); // Line 56
            errorPanel.add(new JLabel("Error loading " + title + ": " + e.getMessage())); // Line 57
            tabbedPane.addTab(title, errorPanel);
        }
    }
}