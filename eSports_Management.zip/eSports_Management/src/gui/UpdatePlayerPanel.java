package gui;

import java.awt.*;
import javax.swing.*;
import eSports_Management.Player;
import eSports_Management.Team;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UpdatePlayerPanel extends JPanel {
    private JComboBox<String> playerComboBox, teamComboBox;
    private JTextField playerNameField, ageField, roleField;

    public UpdatePlayerPanel() {
        setLayout(new GridBagLayout());
        setBackground(new Color(40, 44, 52));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel titleLabel = new JLabel("Update Player");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 26));
        titleLabel.setForeground(Color.WHITE);
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        add(titleLabel, gbc);

        JLabel selectPlayerLabel = new JLabel("Select Player:");
        selectPlayerLabel.setForeground(Color.WHITE);
        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 1;
        add(selectPlayerLabel, gbc);

        playerComboBox = new JComboBox<>();
        populatePlayerComboBox();
        gbc.gridx = 1; gbc.gridy = 1;
        add(playerComboBox, gbc);

        JLabel nameLabel = new JLabel("New Name:");
        nameLabel.setForeground(Color.WHITE);
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 1;
        add(nameLabel, gbc);
        playerNameField = new JTextField(20);
        gbc.gridx = 1; gbc.gridy = 2;
        add(playerNameField, gbc);

        JLabel ageLabel = new JLabel("New Age:");
        ageLabel.setForeground(Color.WHITE);
        gbc.gridx = 0; gbc.gridy = 3;
        add(ageLabel, gbc);
        ageField = new JTextField(20);
        gbc.gridx = 1; gbc.gridy = 3;
        add(ageField, gbc);

        JLabel roleLabel = new JLabel("New Role:");
        roleLabel.setForeground(Color.WHITE);
        gbc.gridx = 0; gbc.gridy = 4;
        add(roleLabel, gbc);
        roleField = new JTextField(20);
        gbc.gridx = 1; gbc.gridy = 4;
        add(roleField, gbc);

        JLabel teamLabel = new JLabel("New Team:");
        teamLabel.setForeground(Color.WHITE);
        gbc.gridx = 0; gbc.gridy = 5;
        add(teamLabel, gbc);
        teamComboBox = new JComboBox<>();
        populateTeamComboBox();
        gbc.gridx = 1; gbc.gridy = 5;
        add(teamComboBox, gbc);

        JButton updateButton = new JButton("Update Player");
        updateButton.setFont(new Font("Arial", Font.BOLD, 16));
        gbc.gridx = 0; gbc.gridy = 6; gbc.gridwidth = 2;
        add(updateButton, gbc);

        playerComboBox.addActionListener(e -> populateFields());
        updateButton.addActionListener(e -> updatePlayer());

        if (playerComboBox.getItemCount() > 0) populateFields();
    }

    private void populatePlayerComboBox() {
        playerComboBox.removeAllItems();
        try (ResultSet rs = Player.listPlayers()) {
            while (rs.next()) {
                String item = rs.getInt("player_id") + ": " + rs.getString("player_name");
                playerComboBox.addItem(item);
                System.out.println("Added player: " + item); // Debug
            }
            System.out.println("Player count: " + playerComboBox.getItemCount()); // Debug
        } catch (SQLException ex) {
            System.out.println("SQL Error (players): " + ex.getMessage()); // Debug
            JOptionPane.showMessageDialog(this, "Error fetching players: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
        playerComboBox.revalidate(); // Force UI update
        playerComboBox.repaint();    // Force UI update
    }

    private void populateTeamComboBox() {
        teamComboBox.removeAllItems();
        try (ResultSet rs = Team.listTeams()) {
            while (rs.next()) {
                teamComboBox.addItem(rs.getInt("team_id") + ": " + rs.getString("team_name"));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error fetching teams: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void populateFields() {
        if (playerComboBox.getSelectedItem() == null) return;
        try {
            int playerId = Integer.parseInt(playerComboBox.getSelectedItem().toString().split(":")[0].trim());
            try (ResultSet rs = Player.listPlayers()) {
                while (rs.next()) {
                    if (rs.getInt("player_id") == playerId) {
                        playerNameField.setText(rs.getString("player_name"));
                        ageField.setText(String.valueOf(rs.getInt("age")));
                        roleField.setText(rs.getString("role"));
                        int teamId = rs.getInt("team_id");
                        for (int i = 0; i < teamComboBox.getItemCount(); i++) {
                            if (teamComboBox.getItemAt(i).startsWith(String.valueOf(teamId))) {
                                teamComboBox.setSelectedIndex(i);
                                break;
                            }
                        }
                        break;
                    }
                }
            }
        } catch (NumberFormatException | SQLException e) {
            JOptionPane.showMessageDialog(this, "Error getting player data: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updatePlayer() {
        if (playerComboBox.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "No player selected.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        try {
            int playerId = Integer.parseInt(playerComboBox.getSelectedItem().toString().split(":")[0].trim());
            String name = playerNameField.getText().trim();
            String ageText = ageField.getText().trim();
            String role = roleField.getText().trim();
            if (name.isEmpty() || ageText.isEmpty() || role.isEmpty() || teamComboBox.getSelectedItem() == null) {
                JOptionPane.showMessageDialog(this, "Please fill all fields.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            int age = Integer.parseInt(ageText);
            int teamId = Integer.parseInt(teamComboBox.getSelectedItem().toString().split(":")[0].trim());
            Player.updatePlayer(playerId, name, age, role, teamId); // Assume implementation exists
            JOptionPane.showMessageDialog(this, "Player updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            populatePlayerComboBox();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid age or team ID.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}