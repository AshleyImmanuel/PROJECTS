package gui;

import java.awt.*;
import javax.swing.*;
import eSports_Management.Team;

public class AddTeamPanel extends JPanel {
    private static final long serialVersionUID = 1L; // Added to suppress serialization warning

    private JTextField teamNameField, regionField;
    private JTabbedPane parentTabbedPane;

    public AddTeamPanel(JTabbedPane parentTabbedPane) {
        this.parentTabbedPane = parentTabbedPane;
        setLayout(new GridBagLayout());
        setBackground(new Color(40, 44, 52));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel titleLabel = new JLabel("Add New Team");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 26));
        titleLabel.setForeground(Color.WHITE);
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        add(titleLabel, gbc);

        JLabel nameLabel = new JLabel("Team Name:");
        nameLabel.setForeground(Color.WHITE);
        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 1;
        add(nameLabel, gbc);

        teamNameField = new JTextField(20);
        gbc.gridx = 1; gbc.gridy = 1;
        add(teamNameField, gbc);

        JLabel regionLabel = new JLabel("Region:");
        regionLabel.setForeground(Color.WHITE);
        gbc.gridx = 0; gbc.gridy = 2;
        add(regionLabel, gbc);

        regionField = new JTextField(20);
        gbc.gridx = 1; gbc.gridy = 2;
        add(regionField, gbc);

        JButton saveButton = new JButton("Save Team");
        saveButton.setFont(new Font("Arial", Font.BOLD, 16));
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        add(saveButton, gbc);

        saveButton.addActionListener(e -> {
            String name = teamNameField.getText().trim();
            String region = regionField.getText().trim();
            if (!name.isEmpty() && !region.isEmpty()) {
                Team newTeam = new Team(name, region);
                newTeam.save(); // No try-catch needed - Team.save() handles SQLException
                JOptionPane.showMessageDialog(this, "Team added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                teamNameField.setText("");
                regionField.setText("");
                Component teamsPanel = parentTabbedPane.getComponentAt(0); // View Teams tab
                if (teamsPanel instanceof ViewTeamsPanel) {
                    ((ViewTeamsPanel) teamsPanel).refreshTable();
                }
            } else {
                JOptionPane.showMessageDialog(this, "Please fill all fields.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }
}