package gui;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.ResultSet;
import java.sql.SQLException;
import eSports_Management.DBConnection;
import eSports_Management.Team;

public class PlayerRosterPanel extends JPanel {
    private JComboBox<String> teamComboBox;
    private JTable playersTable;
    private DefaultTableModel tableModel;

    public PlayerRosterPanel() {
        setLayout(new BorderLayout());
        setBackground(new Color(40, 44, 52));

        JLabel titleLabel = new JLabel("Team Roster");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 26));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(titleLabel, BorderLayout.NORTH);

        JPanel controlPanel = new JPanel(new FlowLayout());
        controlPanel.setBackground(new Color(40, 44, 52));
        JLabel selectTeamLabel = new JLabel("Select Team:");
        selectTeamLabel.setForeground(Color.WHITE);
        teamComboBox = new JComboBox<>();
        populateTeamComboBox();
        controlPanel.add(selectTeamLabel);
        controlPanel.add(teamComboBox);
        add(controlPanel, BorderLayout.NORTH); // Moved to NORTH

        String[] columnNames = {"ID", "Name", "Age", "Role"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        playersTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(playersTable);
        add(scrollPane, BorderLayout.CENTER); // Only one CENTER component

        teamComboBox.addActionListener(e -> refreshPlayerList());
        if (teamComboBox.getItemCount() > 0) {
            refreshPlayerList();
        }
    }

    private void populateTeamComboBox() {
        try (ResultSet rs = Team.listTeams()) {
            while (rs.next()) {
                teamComboBox.addItem(rs.getInt("team_id") + ": " + rs.getString("team_name"));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error fetching teams: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void refreshPlayerList() { // Changed from private to public
        tableModel.setRowCount(0);
        if (teamComboBox.getSelectedItem() == null) return;
        try {
            int teamId = Integer.parseInt(teamComboBox.getSelectedItem().toString().split(":")[0].trim());
            String sql = "SELECT player_id, player_name, age, role FROM players WHERE team_id = ?";
            try (var conn = DBConnection.getConnection();
                 var pst = conn.prepareStatement(sql)) {
                pst.setInt(1, teamId);
                try (var rs = pst.executeQuery()) {
                    while (rs.next()) {
                        tableModel.addRow(new Object[]{
                            rs.getInt("player_id"),
                            rs.getString("player_name"),
                            rs.getInt("age"),
                            rs.getString("role")
                        });
                    }
                }
            }
        } catch (NumberFormatException | SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error fetching roster: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}