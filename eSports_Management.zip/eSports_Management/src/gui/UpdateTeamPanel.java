package gui;

import java.awt.*;
import javax.swing.*;
import eSports_Management.Team;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UpdateTeamPanel extends JPanel {
    private static final long serialVersionUID = 1L; // Added to suppress warning

    private JComboBox<String> teamComboBox;
    private JTextField teamNameField, regionField;

    public UpdateTeamPanel() {
        setLayout(new GridBagLayout());
        setBackground(new Color(40, 44, 52));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel titleLabel = new JLabel("Update Team");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 26));
        titleLabel.setForeground(Color.WHITE);
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        add(titleLabel, gbc);

        JLabel selectLabel = new JLabel("Select Team:");
        selectLabel.setForeground(Color.WHITE);
        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 1;
        add(selectLabel, gbc);

        teamComboBox = new JComboBox<>();
        populateTeamComboBox();
        gbc.gridx = 1; gbc.gridy = 1;
        add(teamComboBox, gbc);

        JLabel nameLabel = new JLabel("New Team Name:");
        nameLabel.setForeground(Color.WHITE);
        gbc.gridx = 0; gbc.gridy = 2;
        add(nameLabel, gbc);

        teamNameField = new JTextField(20);
        gbc.gridx = 1; gbc.gridy = 2;
        add(teamNameField, gbc);

        JLabel regionLabel = new JLabel("New Region:");
        regionLabel.setForeground(Color.WHITE);
        gbc.gridx = 0; gbc.gridy = 3;
        add(regionLabel, gbc);

        regionField = new JTextField(20);
        gbc.gridx = 1; gbc.gridy = 3;
        add(regionField, gbc);

        JButton updateButton = new JButton("Update Team");
        updateButton.setFont(new Font("Arial", Font.BOLD, 16));
        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2;
        add(updateButton, gbc);

        teamComboBox.addActionListener(e -> populateFields());
        updateButton.addActionListener(e -> updateTeam());

        if (teamComboBox.getItemCount() > 0) populateFields();
    }

    private void populateTeamComboBox() {
        teamComboBox.removeAllItems();
        try (ResultSet rs = Team.listTeams()) {
            while (rs.next()) {
                teamComboBox.addItem(rs.getInt("team_id") + ": " + rs.getString("team_name"));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error fetching teams: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void populateFields() {
        if (teamComboBox.getSelectedItem() == null) return;
        try {
            int teamId = Integer.parseInt(teamComboBox.getSelectedItem().toString().split(":")[0].trim());
            try (ResultSet rs = Team.listTeams()) {
                while (rs.next()) {
                    if (rs.getInt("team_id") == teamId) {
                        teamNameField.setText(rs.getString("team_name"));
                        regionField.setText(rs.getString("region"));
                        break;
                    }
                }
            }
        } catch (NumberFormatException | SQLException e) {
            JOptionPane.showMessageDialog(this, "Error getting team data: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateTeam() {
        if (teamComboBox.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "No team selected.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        try {
            int teamId = Integer.parseInt(teamComboBox.getSelectedItem().toString().split(":")[0].trim());
            String name = teamNameField.getText().trim();
            String region = regionField.getText().trim();
            if (!name.isEmpty() && !region.isEmpty()) {
                Team.updateTeam(teamId, name, region); // Assume implementation exists
                JOptionPane.showMessageDialog(this, "Team updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                populateTeamComboBox();
            } else {
                JOptionPane.showMessageDialog(this, "Please fill all fields.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid team ID format.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}