package gui;

import java.awt.*;
import javax.swing.*;
import eSports_Management.Player;
import eSports_Management.Team;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AddPlayerPanel extends JPanel {
    private JTextField playerNameField, ageField, roleField;
    private JComboBox<String> teamComboBox;
    private JTabbedPane parentTabbedPane;

    public AddPlayerPanel(JTabbedPane parentTabbedPane) {
        this.parentTabbedPane = parentTabbedPane;
        setLayout(new GridBagLayout());
        setBackground(new Color(40, 44, 52));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel titleLabel = new JLabel("Add New Player");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 26));
        titleLabel.setForeground(Color.WHITE);
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        add(titleLabel, gbc);

        JLabel nameLabel = new JLabel("Player Name:");
        nameLabel.setForeground(Color.WHITE);
        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 1;
        add(nameLabel, gbc);

        playerNameField = new JTextField(20);
        gbc.gridx = 1; gbc.gridy = 1;
        add(playerNameField, gbc);

        JLabel ageLabel = new JLabel("Age:");
        ageLabel.setForeground(Color.WHITE);
        gbc.gridx = 0; gbc.gridy = 2;
        add(ageLabel, gbc);

        ageField = new JTextField(20);
        gbc.gridx = 1; gbc.gridy = 2;
        add(ageField, gbc);

        JLabel roleLabel = new JLabel("Role:");
        roleLabel.setForeground(Color.WHITE);
        gbc.gridx = 0; gbc.gridy = 3;
        add(roleLabel, gbc);

        roleField = new JTextField(20);
        gbc.gridx = 1; gbc.gridy = 3;
        add(roleField, gbc);

        JLabel teamLabel = new JLabel("Team:");
        teamLabel.setForeground(Color.WHITE);
        gbc.gridx = 0; gbc.gridy = 4;
        add(teamLabel, gbc);

        teamComboBox = new JComboBox<>();
        populateTeamComboBox();
        gbc.gridx = 1; gbc.gridy = 4;
        add(teamComboBox, gbc);

        JButton saveButton = new JButton("Save Player");
        saveButton.setFont(new Font("Arial", Font.BOLD, 16));
        gbc.gridx = 0; gbc.gridy = 5; gbc.gridwidth = 2;
        add(saveButton, gbc);

        saveButton.addActionListener(e -> {
            String name = playerNameField.getText().trim();
            String ageText = ageField.getText().trim();
            String role = roleField.getText().trim();
            if (name.isEmpty() || ageText.isEmpty() || role.isEmpty() || teamComboBox.getSelectedItem() == null) {
                JOptionPane.showMessageDialog(this, "Please fill all fields.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            try {
                int age = Integer.parseInt(ageText);
                int teamId = Integer.parseInt(teamComboBox.getSelectedItem().toString().split(":")[0].trim());
                Player newPlayer = new Player(name, age, role, teamId);
                newPlayer.save();
                JOptionPane.showMessageDialog(this, "Player added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                playerNameField.setText("");
                ageField.setText("");
                roleField.setText("");
                Component viewPlayers = parentTabbedPane.getComponentAt(2); // View Players tab
                if (viewPlayers instanceof ViewPlayersPanel) {
                    ((ViewPlayersPanel) viewPlayers).refreshTable();
                }
                Component roster = parentTabbedPane.getComponentAt(4); // Team Roster tab
                if (roster instanceof PlayerRosterPanel) {
                    ((PlayerRosterPanel) roster).refreshPlayerList();
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid age or team ID.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private void populateTeamComboBox() {
        try (ResultSet rs = Team.listTeams()) {
            while (rs.next()) {
                String item = rs.getInt("team_id") + ": " + rs.getString("team_name");
                teamComboBox.addItem(item);
                System.out.println("Added to combo: " + item); // Debug
            }
            System.out.println("Team count: " + teamComboBox.getItemCount()); // Debug
        } catch (SQLException ex) {
            System.out.println("SQL Error: " + ex.getMessage()); // Debug
            JOptionPane.showMessageDialog(this, "Error fetching teams: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
        teamComboBox.revalidate(); // Force UI update
        teamComboBox.repaint();    // Force UI update
    }
}