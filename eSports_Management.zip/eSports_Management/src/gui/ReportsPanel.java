package gui;

import java.awt.*;
import javax.swing.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import eSports_Management.DBConnection;

public class ReportsPanel extends JPanel {
    private JLabel totalTeamsLabel, totalPlayersLabel;

    public ReportsPanel() {
        setLayout(new GridBagLayout());
        setBackground(new Color(40, 44, 52));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 15, 15, 15);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel titleLabel = new JLabel("System Reports");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 26));
        titleLabel.setForeground(Color.WHITE);
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        add(titleLabel, gbc);

        totalTeamsLabel = new JLabel("Total Teams: 0");
        totalTeamsLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        totalTeamsLabel.setForeground(Color.CYAN);
        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 1;
        add(totalTeamsLabel, gbc);

        totalPlayersLabel = new JLabel("Total Players: 0");
        totalPlayersLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        totalPlayersLabel.setForeground(Color.MAGENTA);
        gbc.gridx = 1; gbc.gridy = 1; gbc.gridwidth = 1;
        add(totalPlayersLabel, gbc);

        fetchReportData();
    }

    private void fetchReportData() {
        try (var conn = DBConnection.getConnection();
             var stmt = conn.createStatement()) {
            try (ResultSet rsTeams = stmt.executeQuery("SELECT COUNT(*) AS total FROM teams")) {
                if (rsTeams.next()) {
                    totalTeamsLabel.setText("Total Teams: " + rsTeams.getInt("total"));
                }
            }
            try (ResultSet rsPlayers = stmt.executeQuery("SELECT COUNT(*) AS total FROM players")) {
                if (rsPlayers.next()) {
                    totalPlayersLabel.setText("Total Players: " + rsPlayers.getInt("total"));
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error fetching reports: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}