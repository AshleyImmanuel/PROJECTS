package gui;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.ResultSet;
import java.sql.SQLException;
import eSports_Management.Player;

public class ViewPlayersPanel extends JPanel {
    private JTable playersTable;
    private DefaultTableModel tableModel;

    public ViewPlayersPanel() {
        setLayout(new BorderLayout());
        setBackground(new Color(40, 44, 52));

        JLabel titleLabel = new JLabel("Manage Players");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 26));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(titleLabel, BorderLayout.NORTH);

        String[] columnNames = {"ID", "Name", "Age", "Role", "Team ID"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        playersTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(playersTable);
        add(scrollPane, BorderLayout.CENTER);

        JButton refreshButton = new JButton("Refresh List");
        refreshButton.setFont(new Font("Arial", Font.BOLD, 14)); // Styled
        refreshButton.addActionListener(e -> refreshTable());

        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(new Color(40, 44, 52));
        buttonPanel.add(refreshButton);
        add(buttonPanel, BorderLayout.SOUTH);

        refreshTable();
    }

    public void refreshTable() {
        tableModel.setRowCount(0);
        try (ResultSet rs = Player.listPlayers()) {
            while (rs.next()) {
                tableModel.addRow(new Object[]{
                    rs.getInt("player_id"),
                    rs.getString("player_name"),
                    rs.getInt("age"),
                    rs.getString("role"),
                    rs.getInt("team_id")
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error fetching players: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}