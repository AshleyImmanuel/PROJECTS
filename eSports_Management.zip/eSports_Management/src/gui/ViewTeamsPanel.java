package gui;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.ResultSet;
import java.sql.SQLException;
import eSports_Management.Team;

public class ViewTeamsPanel extends JPanel {
    private static final long serialVersionUID = 1L; // Added to suppress serialization warning

    private JTable teamsTable;
    private DefaultTableModel tableModel;

    public ViewTeamsPanel() {
        setLayout(new BorderLayout());
        setBackground(new Color(40, 44, 52));

        JLabel titleLabel = new JLabel("Manage Teams");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 26));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(titleLabel, BorderLayout.NORTH);

        String[] columnNames = {"ID", "Team Name", "Region"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        teamsTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(teamsTable);
        add(scrollPane, BorderLayout.CENTER);

        JButton refreshButton = new JButton("Refresh List");
        refreshButton.setFont(new Font("Arial", Font.BOLD, 14)); // Styled
        refreshButton.addActionListener(e -> refreshTable());

        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(new Color(40, 44, 52));
        buttonPanel.add(refreshButton);
        add(buttonPanel, BorderLayout.SOUTH);

        refreshTable();
    }

    public void refreshTable() {
        tableModel.setRowCount(0);
        try (ResultSet rs = Team.listTeams()) {
            while (rs.next()) {
                tableModel.addRow(new Object[]{
                    rs.getInt("team_id"),
                    rs.getString("team_name"),
                    rs.getString("region")
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error fetching teams: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}