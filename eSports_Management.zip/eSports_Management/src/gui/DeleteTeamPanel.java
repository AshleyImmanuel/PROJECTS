package gui;

import java.awt.*;
import javax.swing.*;
import eSports_Management.Team;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DeleteTeamPanel extends JPanel {
    private JComboBox<String> teamComboBox;
    private JTabbedPane parentTabbedPane; // Added to refresh other panels

    public DeleteTeamPanel() {
        this.parentTabbedPane = null; // Initialize if needed, or pass via constructor
        setLayout(new GridBagLayout());
        setBackground(new Color(40, 44, 52));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel titleLabel = new JLabel("Delete Team");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 26));
        titleLabel.setForeground(Color.WHITE);
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        add(titleLabel, gbc);

        JLabel selectLabel = new JLabel("Select Team to Delete:");
        selectLabel.setForeground(Color.WHITE);
        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 1;
        add(selectLabel, gbc);

        teamComboBox = new JComboBox<>();
        populateTeamComboBox();
        gbc.gridx = 1; gbc.gridy = 1;
        add(teamComboBox, gbc);

        JButton deleteButton = new JButton("Delete Team");
        deleteButton.setFont(new Font("Arial", Font.BOLD, 16));
        deleteButton.setBackground(Color.RED);
        deleteButton.setForeground(Color.WHITE);
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2;
        add(deleteButton, gbc);

        deleteButton.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this team? All players will be unassigned.", "Confirm Delete", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                deleteTeam();
            }
        });
    }

    private void populateTeamComboBox() {
        teamComboBox.removeAllItems();
        try (ResultSet rs = Team.listTeams()) {
            while (rs.next()) {
                teamComboBox.addItem(rs.getInt("team_id") + ": " + rs.getString("team_name"));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error fetching teams: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteTeam() {
        if (teamComboBox.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "No team selected.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        try {
            int teamId = Integer.parseInt(teamComboBox.getSelectedItem().toString().split(":")[0].trim());
            Team.deleteTeam(teamId); // Assume implementation exists
            JOptionPane.showMessageDialog(this, "Team deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            populateTeamComboBox();
            // Refresh related panels if parentTabbedPane is set
            if (parentTabbedPane != null) {
                Component teamsPanel = parentTabbedPane.getComponentAt(0);
                if (teamsPanel instanceof ViewTeamsPanel) {
                    ((ViewTeamsPanel) teamsPanel).refreshTable();
                }
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid team ID format.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}