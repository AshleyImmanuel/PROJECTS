package gui;

import java.awt.*;
import javax.swing.*;
import eSports_Management.Player;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DeletePlayerPanel extends JPanel {
    private JComboBox<String> playerComboBox;
    private JTabbedPane parentTabbedPane; // Added to refresh other panels

    public DeletePlayerPanel() {
        this.parentTabbedPane = null; // Initialize if needed, or pass via constructor
        setLayout(new GridBagLayout());
        setBackground(new Color(40, 44, 52));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel titleLabel = new JLabel("Delete Player");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 26));
        titleLabel.setForeground(Color.WHITE);
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        add(titleLabel, gbc);

        JLabel selectPlayerLabel = new JLabel("Select Player to Delete:");
        selectPlayerLabel.setForeground(Color.WHITE);
        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 1;
        add(selectPlayerLabel, gbc);

        playerComboBox = new JComboBox<>();
        populatePlayerComboBox();
        gbc.gridx = 1; gbc.gridy = 1;
        add(playerComboBox, gbc);

        JButton deleteButton = new JButton("Delete Player");
        deleteButton.setFont(new Font("Arial", Font.BOLD, 16));
        deleteButton.setBackground(Color.RED);
        deleteButton.setForeground(Color.WHITE);
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2;
        add(deleteButton, gbc);

        deleteButton.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this player?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                deletePlayer();
            }
        });
    }

    private void populatePlayerComboBox() {
        playerComboBox.removeAllItems();
        try (ResultSet rs = Player.listPlayers()) {
            while (rs.next()) {
                playerComboBox.addItem(rs.getInt("player_id") + ": " + rs.getString("player_name"));
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error fetching players: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deletePlayer() {
        if (playerComboBox.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "No player selected.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        try {
            int playerId = Integer.parseInt(playerComboBox.getSelectedItem().toString().split(":")[0].trim());
            Player.deletePlayer(playerId); // Assume implementation exists
            JOptionPane.showMessageDialog(this, "Player deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            populatePlayerComboBox();
            // Refresh related panels if parentTabbedPane is set
            if (parentTabbedPane != null) {
                Component viewPlayers = parentTabbedPane.getComponentAt(2);
                if (viewPlayers instanceof ViewPlayersPanel) {
                    ((ViewPlayersPanel) viewPlayers).refreshTable();
                }
                Component roster = parentTabbedPane.getComponentAt(4);
                if (roster instanceof PlayerRosterPanel) {
                    ((PlayerRosterPanel) roster).refreshPlayerList();
                }
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid player ID format.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}