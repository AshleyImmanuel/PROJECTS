package eSports_Management;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Team {

    private String teamName;
    private String region;

    public Team(String teamName, String region) {
        this.teamName = teamName;
        this.region = region;
    }

    // Add a new team to the database
    public void save() {
        String sql = "INSERT INTO teams (team_name, region) VALUES (?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setString(1, teamName);
            pst.setString(2, region);
            pst.executeUpdate();

            System.out.println("Team added successfully!");

        } catch (SQLException e) {
            System.out.println("Error adding team: " + e.getMessage());
        }
    }

    // List all teams - Updated to return ResultSet
    public static ResultSet listTeams() throws SQLException {
        Connection conn = DBConnection.getConnection();
        Statement stmt = conn.createStatement();
        return stmt.executeQuery("SELECT * FROM teams"); // Returns ResultSet for GUI use
    }

    // Update team details
    public static void updateTeam(int id, String name, String region) {
        String sql = "UPDATE teams SET team_name = ?, region = ? WHERE team_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setString(1, name);
            pst.setString(2, region);
            pst.setInt(3, id);

            int rows = pst.executeUpdate();
            if (rows > 0) System.out.println("Team updated successfully!");
            else System.out.println("No team found with ID " + id);

        } catch (SQLException e) {
            System.out.println("Error updating team: " + e.getMessage());
        }
    }

    // Delete a team
    public static void deleteTeam(int id) {
        String sql = "DELETE FROM teams WHERE team_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setInt(1, id);
            int rows = pst.executeUpdate();

            if (rows > 0) System.out.println("Team deleted successfully!");
            else System.out.println("No team found with ID " + id);

        } catch (SQLException e) {
            System.out.println("Error deleting team: " + e.getMessage());
        }
    }
}