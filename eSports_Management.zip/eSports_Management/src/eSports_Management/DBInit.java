package eSports_Management;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class DBInit {

    public static void createTables() {
        // SQL for Teams table
        String createTeams = """
            CREATE TABLE IF NOT EXISTS teams (
                team_id INT AUTO_INCREMENT PRIMARY KEY,
                team_name VARCHAR(50) NOT NULL,
                region VARCHAR(50)
            )
            """;

        // SQL for Players table
        String createPlayers = """
            CREATE TABLE IF NOT EXISTS players (
                player_id INT AUTO_INCREMENT PRIMARY KEY,
                player_name VARCHAR(50) NOT NULL,
                age INT,
                role VARCHAR(50),
                team_id INT,
                FOREIGN KEY (team_id) REFERENCES teams(team_id) ON DELETE SET NULL
            )
            """;

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement()) {

            stmt.execute(createTeams);
            stmt.execute(createPlayers);

            System.out.println("Tables are ready!");

        } catch (SQLException e) {
            System.out.println("Error creating tables: " + e.getMessage());
        }
    }
}
