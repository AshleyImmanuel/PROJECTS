package eSports_Management;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Player {

    private String playerName;
    private int age;
    private String role;
    private int teamId;

    public Player(String playerName, int age, String role, int teamId) {
        this.playerName = playerName;
        this.age = age;
        this.role = role;
        this.teamId = teamId;
    }

    // Add a new player to the database
    public void save() {
        String sql = "INSERT INTO players (player_name, age, role, team_id) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setString(1, playerName);
            pst.setInt(2, age);
            pst.setString(3, role);
            pst.setInt(4, teamId);

            pst.executeUpdate();
            System.out.println("Player added successfully!");

        } catch (SQLException e) {
            System.out.println("Error adding player: " + e.getMessage());
        }
    }

    // List all players - Updated to return ResultSet
    public static ResultSet listPlayers() throws SQLException {
        Connection conn = DBConnection.getConnection();
        Statement stmt = conn.createStatement();
        return stmt.executeQuery("SELECT * FROM players"); // Returns ResultSet for GUI use
    }

    // Update player details
    public static void updatePlayer(int id, String name, int age, String role, int teamId) {
        String sql = "UPDATE players SET player_name = ?, age = ?, role = ?, team_id = ? WHERE player_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setString(1, name);
            pst.setInt(2, age);
            pst.setString(3, role);
            pst.setInt(4, teamId);
            pst.setInt(5, id);

            int rows = pst.executeUpdate();
            if (rows > 0) System.out.println("Player updated successfully!");
            else System.out.println("No player found with ID " + id);

        } catch (SQLException e) {
            System.out.println("Error updating player: " + e.getMessage());
        }
    }

    // Delete a player
    public static void deletePlayer(int id) {
        String sql = "DELETE FROM players WHERE player_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setInt(1, id);
            int rows = pst.executeUpdate();

            if (rows > 0) System.out.println("Player deleted successfully!");
            else System.out.println("No player found with ID " + id);

        } catch (SQLException e) {
            System.out.println("Error deleting player: " + e.getMessage());
        }
    }
}